const saibaMaisBtn = document.querySelector('.saiba-mais-btn')
const noticiaContainer = document.querySelector('.noticia-container')
const closeBtn = document.querySelector('.close-btn')

saibaMaisBtn.addEventListener('click', ()=> {
    noticiaContainer.style.transform = "translateX(0)"
})


closeBtn.addEventListener('click', ()=> {
    noticiaContainer.style.transform = "translateX(-2000px)"
})
